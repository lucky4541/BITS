"""Step 5/4 (spec: "METADATA DETECTION" / "AUTO-CAPTURE METADATA") -
automatically detects title/subtitle/author/language/publisher/
publication date/edition from the CURRENT project, so the user is never
asked to type them. Priority, exactly as specified: existing valid OPF
metadata -> XHTML metadata -> title page -> copyright page -> other
structured metadata. A field this cascade genuinely cannot determine is
left empty with an honest reason - never guessed, never filled with a
placeholder."""
import posixpath
import re
from dataclasses import dataclass, field

from lxml import etree

from core.epub_structure.xhtml_parser import local_name

OPF_NS = "http://www.idpf.org/2007/opf"
DC_NS = "http://purl.org/dc/elements/1.1/"
_DC = f"{{{DC_NS}}}"
_OPF = f"{{{OPF_NS}}}"


@dataclass
class MetadataField:
    value: str = ""
    source: str = ""      # e.g. "existing OPF", "title page (02_..._fm1.xhtml)", "copyright page (...)"
    confidence: str = ""   # "HIGH" / "MEDIUM" / ""(not found)


@dataclass
class DetectedMetadata:
    title: MetadataField = field(default_factory=MetadataField)
    subtitle: MetadataField = field(default_factory=MetadataField)
    author: MetadataField = field(default_factory=MetadataField)
    language: MetadataField = field(default_factory=MetadataField)
    publisher: MetadataField = field(default_factory=MetadataField)
    publication_date: MetadataField = field(default_factory=MetadataField)
    edition: MetadataField = field(default_factory=MetadataField)
    conflicts: list = field(default_factory=list)   # human-readable strings, when 2+ sources disagreed

    def missing_fields(self) -> list:
        return [name for name in ("title", "author", "language") if not getattr(self, name).value]


def _read_existing_opf(scan) -> dict:
    """Returns a dict of raw values found in an EXISTING, valid OPF's own
    <metadata> - the highest-priority source. Never raises on a missing/
    malformed OPF; simply returns {}."""
    if not scan.opf_path:
        return {}
    try:
        with open(scan.abspath(scan.opf_path), "rb") as f:
            raw = f.read()
        tree = etree.fromstring(raw)
    except (OSError, etree.XMLSyntaxError):
        return {}

    found = {}
    metadata_el = next((e for e in tree.iter() if local_name(e.tag) == "metadata"), None)
    if metadata_el is None:
        return found

    title_el = next((e for e in metadata_el if local_name(e.tag) == "title"), None)
    if title_el is not None and (title_el.text or "").strip():
        found["title"] = title_el.text.strip()
    creator_el = next((e for e in metadata_el if local_name(e.tag) == "creator"), None)
    if creator_el is not None and (creator_el.text or "").strip():
        found["author"] = creator_el.text.strip()
    lang_el = next((e for e in metadata_el if local_name(e.tag) == "language"), None)
    if lang_el is not None and (lang_el.text or "").strip():
        found["language"] = lang_el.text.strip()
    date_el = next((e for e in metadata_el if local_name(e.tag) == "date"), None)
    if date_el is not None and (date_el.text or "").strip():
        found["publication_date"] = date_el.text.strip()

    for meta_el in metadata_el:
        if local_name(meta_el.tag) != "meta":
            continue
        prop = (meta_el.get("property") or "").lower()
        text = (meta_el.text or "").strip()
        if not text:
            continue
        if prop == "dcterms:publisher" and "publisher" not in found:
            found["publisher"] = text
        elif prop == "title-type" and text.lower() == "subtitle":
            refines = (meta_el.get("refines") or "").lstrip("#")
            subtitle_el = next((e for e in metadata_el
                                 if local_name(e.tag) == "title" and e.get("id") == refines), None)
            if subtitle_el is not None and (subtitle_el.text or "").strip():
                found["subtitle"] = subtitle_el.text.strip()
        elif prop in ("schema:bookedition", "belongs-to-collection") and "edition" not in found:
            found["edition"] = text
    return found


_COPYRIGHT_KEYWORDS = ("copyright", "all rights reserved", "isbn", "published by", "printed in")
_EDITION_RE = re.compile(r"\b(\d+(?:st|nd|rd|th)\s+edition|second edition|third edition|"
                          r"fourth edition|fifth edition)\b", re.IGNORECASE)


def _extract_plain_text(scan, path: str) -> str:
    try:
        with open(scan.abspath(path), "rb") as f:
            raw = f.read()
        tree = etree.fromstring(raw)
    except (OSError, etree.XMLSyntaxError):
        return ""
    return " ".join(tree.itertext())


def _looks_like_copyright_page(text: str) -> bool:
    lowered = text.lower()
    return sum(1 for kw in _COPYRIGHT_KEYWORDS if kw in lowered) >= 2


def detect_metadata(scan, registry) -> DetectedMetadata:
    """THE single entry point. `registry`: the already-built
    core.epub_structure.registry.GlobalRegistry for this project (reused,
    never re-parsed) - `scan` is only needed for the one extra raw-text
    read of the copyright page (not part of the registry's own per-
    document model)."""
    result = DetectedMetadata()
    opf_values = _read_existing_opf(scan)

    for field_name in ("title", "subtitle", "author", "language", "publisher", "publication_date", "edition"):
        if field_name in opf_values:
            setattr(result, field_name, MetadataField(
                value=opf_values[field_name], source="existing OPF metadata", confidence="HIGH"))

    if not result.title.value:
        halftitle = next((d for d in registry.documents if d.document_type in ("halftitle", "titlepage")), None)
        if halftitle is not None and halftitle.title:
            result.title = MetadataField(value=halftitle.title, source=f"title page ({halftitle.path})",
                                          confidence="MEDIUM")

    if not result.language.value:
        result.language = MetadataField(value="en", source="default (not detectable from content)",
                                         confidence="MEDIUM")

    if not result.edition.value:
        for doc in registry.documents:
            if doc.document_type not in ("titlepage", "halftitle", "copyrightpage", "frontmatter"):
                continue
            text = _extract_plain_text(scan, doc.path)
            m = _EDITION_RE.search(text)
            if m:
                result.edition = MetadataField(value=m.group(1), source=f"title/copyright page ({doc.path})",
                                                confidence="MEDIUM")
                break

    copyright_doc = next((d for d in registry.documents if d.document_type == "copyrightpage"), None)
    if copyright_doc is None:
        for doc in registry.documents[:6]:
            text = _extract_plain_text(scan, doc.path)
            if _looks_like_copyright_page(text):
                copyright_doc = doc
                break

    if copyright_doc is not None and not result.publisher.value:
        text = _extract_plain_text(scan, copyright_doc.path)
        m = re.search(r"published by\s+([A-Z][A-Za-z0-9 &.,'-]{2,60})", text, re.IGNORECASE)
        if m:
            result.publisher = MetadataField(value=m.group(1).strip().rstrip(".,"),
                                              source=f"copyright page ({copyright_doc.path})", confidence="MEDIUM")

    if copyright_doc is not None and not result.publication_date.value:
        text = _extract_plain_text(scan, copyright_doc.path)
        m = re.search(r"\b(19|20)\d{2}\b", text)
        if m:
            result.publication_date = MetadataField(value=m.group(0),
                                                      source=f"copyright page ({copyright_doc.path})",
                                                      confidence="MEDIUM")

    return result
