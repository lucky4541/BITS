"""Difference list + category filter (spec section 48) - a Treeview of
every Difference the engine found, with the exact filter set spec 48
lists, plus a selection callback so the host window can drive the
synchronized viewer / detail panel (spec section 49)."""
import tkinter as tk
from tkinter import ttk

from gui import theme
from core.fidelity_compare.score_calculator import is_production_error, SUMMARY_TYPE_BUCKETS

FILTERS = [
    "Production Errors Only", "Need Review", "Informational / Layout", "All",
    "Character Errors", "Word Errors", "Paragraph Errors",
    "Missing", "Added", "Changed", "Merged", "Split", "Missing Space",
    "Merged Word", "Unicode", "Homoglyph", "Special Character", "Hyphenation", "Alignment", "Position",
    "Indentation", "Margin", "Font", "Line Spacing", "Paragraph Spacing", "Columns",
    "Figures", "Tables", "Captions", "Footnotes", "References", "Index", "Links", "OCR Uncertain",
]

# "Character Errors"/"Word Errors"/"Paragraph Errors" (spec: "INTERACTIVE
# ERROR CARDS + EXACT DIFFERENCE VIEW" section 1/20/32) are built directly
# from the SAME type buckets core.fidelity_compare.score_calculator.
# summarize_differences() counts for the dashboard's own cards - clicking
# "208 CHARACTER ERRORS" and this filter showing a different count would
# mean the two were defined independently and could disagree; they can't,
# because there is only one definition.
_BUCKET_FILTER_NAMES = {"character_errors": "Character Errors", "word_errors": "Word Errors",
                         "paragraph_errors": "Paragraph Errors"}


def _bucket_predicate(types):
    return lambda d: d.type in types


_FILTER_MATCH = {
    # Spec: "PAGE-WISE SIDE-BY-SIDE" section 32 - "Do not let MARGIN_
    # CHANGED, minor positioning, anti-aliasing, rendering noise fill the
    # main error list. Default: Production Errors Only." Reuses the SAME
    # HIGH-severity/content-unicode-structure criterion core.fidelity_
    # compare.score_calculator.production_status() already uses for the
    # PASS/FAIL gate, so "what counts as a real error" is never defined in
    # two different, potentially-disagreeing places.
    "Production Errors Only": is_production_error,
    "Need Review": lambda d: d.confidence == "LOW" or getattr(d, "uncertain", False),
    "Informational / Layout": lambda d: not is_production_error(d) and d.confidence != "LOW",
    "Missing": lambda d: d.type.startswith("MISSING"),
    "Added": lambda d: d.type.startswith("ADDED"),
    "Changed": lambda d: d.type.startswith("CHANGED") or d.type in ("ALIGNMENT_CHANGED",),
    "Merged": lambda d: "MERGED" in d.type,
    "Split": lambda d: "SPLIT" in d.type,
    "Missing Space": lambda d: d.type == "MISSING_SPACE",
    "Merged Word": lambda d: d.type == "MERGED_WORD",
    "Unicode": lambda d: d.category == "unicode",
    "Homoglyph": lambda d: d.type == "HOMOGLYPH_SUBSTITUTION",
    "Special Character": lambda d: d.type == "SPECIAL_CHARACTER_CHANGED",
    "Hyphenation": lambda d: d.category == "hyphenation",
    "Alignment": lambda d: d.type == "ALIGNMENT_CHANGED",
    "Position": lambda d: "MOVED" in d.type or "POSITION" in d.type,
    "Indentation": lambda d: "INDENTATION" in d.type,
    "Margin": lambda d: d.type == "MARGIN_CHANGED",
    "Font": lambda d: "FONT" in d.type or d.type in ("BOLD_CHANGED", "ITALIC_CHANGED", "UNDERLINE_CHANGED",
                                                       "SUPERSCRIPT_CHANGED", "SUBSCRIPT_CHANGED"),
    "Line Spacing": lambda d: d.type == "LINE_SPACING_CHANGED",
    "Paragraph Spacing": lambda d: d.type == "PARAGRAPH_SPACING_CHANGED",
    "Columns": lambda d: "COLUMN" in d.type,
    "Figures": lambda d: d.category == "figure",
    "Tables": lambda d: d.category == "table",
    "Captions": lambda d: "CAPTION" in d.type,
    "Footnotes": lambda d: d.category == "footnote",
    "References": lambda d: d.category == "reference",
    "Index": lambda d: d.category == "index",
    "Links": lambda d: d.category == "link",
    "OCR Uncertain": lambda d: d.category == "ocr" or d.confidence == "LOW",
}
for _bucket_key, _filter_name in _BUCKET_FILTER_NAMES.items():
    _FILTER_MATCH[_filter_name] = _bucket_predicate(SUMMARY_TYPE_BUCKETS[_bucket_key])


class DifferencePanel(ttk.Frame):
    def __init__(self, parent, on_select=None):
        super().__init__(parent)
        self._on_select = on_select
        self._differences = []
        self._visible_row_ids = []  # currently-shown row order, for Prev/Next (spec sections 45/47)
        self._current_index = -1
        palette = theme.current.palette

        top = tk.Frame(self, bg=palette["app_bg"])
        top.pack(fill=tk.X, pady=(0, 4))
        tk.Label(top, text="Filter:", bg=palette["app_bg"], fg=palette["text"],
                 font=theme.FONT_BODY).pack(side=tk.LEFT, padx=(0, 6))
        self.filter_var = tk.StringVar(value="Production Errors Only")
        combo = ttk.Combobox(top, textvariable=self.filter_var, values=FILTERS, state="readonly", width=20)
        combo.pack(side=tk.LEFT)
        combo.bind("<<ComboboxSelected>>", lambda e: self._refresh())
        self.count_label = tk.Label(top, text="", bg=palette["app_bg"], fg=palette["text_muted"],
                                     font=theme.FONT_SMALL)
        self.count_label.pack(side=tk.RIGHT)

        # Previous/Next Difference navigation (spec sections 45-47:
        # "Provide: Previous Difference / Next Difference", "Difference 17
        # of 243", "F7 = Next Difference, Shift+F7 = Previous Difference").
        nav = tk.Frame(self, bg=palette["app_bg"])
        nav.pack(fill=tk.X, pady=(0, 4))
        tk.Button(nav, text="< Previous Difference", command=self.select_previous).pack(side=tk.LEFT)
        tk.Button(nav, text="Next Difference >", command=self.select_next).pack(side=tk.LEFT, padx=(6, 0))
        self.position_label = tk.Label(nav, text="No differences", bg=palette["app_bg"], fg=palette["text_muted"],
                                        font=theme.FONT_SMALL)
        self.position_label.pack(side=tk.LEFT, padx=12)

        columns = ("severity", "type", "category", "confidence", "pages")
        self.tree = ttk.Treeview(self, columns=columns, show="headings", selectmode="browse")
        for col, width in zip(columns, (70, 220, 90, 110, 110)):
            self.tree.heading(col, text=col.title())
            self.tree.column(col, width=width, anchor="w")
        vsb = ttk.Scrollbar(self, orient="vertical", command=self.tree.yview)
        self.tree.configure(yscrollcommand=vsb.set)
        self.tree.pack(side=tk.LEFT, fill=tk.BOTH, expand=True)
        vsb.pack(side=tk.LEFT, fill=tk.Y)
        self.tree.bind("<<TreeviewSelect>>", self._on_tree_select)
        # Bound on the Treeview widget itself (not bind_all) so F7/Shift+F7
        # only navigate differences while this panel's own tree actually
        # has keyboard focus (spec 47: "Make shortcuts configurable" - this
        # is the one place to remap them) - a host window with multiple
        # panels keeps full control of its own, separate global shortcuts.
        self.tree.bind("<F7>", lambda e: (self.select_next(), "break")[1])
        self.tree.bind("<Shift-F7>", lambda e: (self.select_previous(), "break")[1])
        self._row_to_diff = {}
        self._search_query = ""

    def set_differences(self, differences: list):
        self._differences = differences
        self._refresh()

    def search(self, query: str) -> int:
        """Spec section 69: "Search Text / Search Difference / Search
        Error Type / Search Page / Search Unicode" - ONE query matched
        against every field a difference already exposes, combined WITH
        (never replacing) whatever category filter is currently active -
        self._differences (the full, real result set) is never mutated,
        so a card click or filter change after a search still sees
        everything. Returns the number of matches; selects the first one
        if any exist. An empty query clears the search back to "no
        restriction" (equivalent to the current filter alone)."""
        self._search_query = (query or "").strip().lower()
        self._refresh()
        if self._visible_row_ids:
            self.select_next()
        return len(self._visible_row_ids)

    def _matches_search(self, d) -> bool:
        if not self._search_query:
            return True
        haystack = [str(d.type), str(d.category), str(d.original_text), str(d.converted_text),
                    str(d.original_page or ""), str(d.converted_page or ""), str(d.explanation or "")]
        for u in (d.original_unicode, d.converted_unicode):
            if u:
                haystack.append(str(u.get("codepoint", "")))
                haystack.append(str(u.get("name", "")))
                haystack.append(str(u.get("char", "")))
        return any(self._search_query in h.lower() for h in haystack)

    def _refresh(self):
        for item in self.tree.get_children():
            self.tree.delete(item)
        self._row_to_diff = {}
        self._visible_row_ids = []
        self._current_index = -1
        filt = self.filter_var.get()
        predicate = _FILTER_MATCH.get(filt)
        shown = 0
        for d in self._differences:
            if predicate and not predicate(d):
                continue
            if not self._matches_search(d):
                continue
            pages = f"{d.original_page or '-'} -> {d.converted_page or '-'}"
            row_id = self.tree.insert("", tk.END, values=(d.severity, d.type, d.category, d.confidence, pages))
            self._row_to_diff[row_id] = d
            self._visible_row_ids.append(row_id)
            shown += 1
        self.count_label.configure(text=f"{shown} / {len(self._differences)} shown")
        self._update_position_label()

    def _update_position_label(self):
        total = len(self._visible_row_ids)
        if total == 0:
            self.position_label.configure(text="No differences")
        elif self._current_index < 0:
            self.position_label.configure(text=f"0 of {total}")
        else:
            self.position_label.configure(text=f"Difference {self._current_index + 1} of {total}")

    def apply_filter_and_select_first(self, filter_name: str) -> bool:
        """Spec: "INTERACTIVE ERROR CARDS + EXACT DIFFERENCE VIEW" section
        1/32 - clicking a summary card must "1. Apply corresponding
        filter, 2. Select first matching difference" in one step (the
        remaining steps - navigate both viewers, scroll, highlight, show
        details - happen automatically because selecting a row already
        fires the SAME on_select callback a manual click would). Returns
        True if at least one matching difference was found and selected."""
        if filter_name not in FILTERS:
            return False
        self._search_query = ""  # a stale search must never hide what the clicked card promised to show
        self.filter_var.set(filter_name)
        self._refresh()
        if not self._visible_row_ids:
            return False
        self.select_next()  # _current_index is -1 right after _refresh(), so this lands on index 0
        return True

    def select_next(self):
        if not self._visible_row_ids:
            return
        self._select_at((self._current_index + 1) % len(self._visible_row_ids))

    def select_previous(self):
        if not self._visible_row_ids:
            return
        self._select_at((self._current_index - 1) % len(self._visible_row_ids))

    def _select_at(self, index: int):
        row_id = self._visible_row_ids[index]
        self.tree.selection_set(row_id)
        self.tree.see(row_id)
        self._current_index = index
        self._update_position_label()
        diff = self._row_to_diff.get(row_id)
        if diff and self._on_select:
            self._on_select(diff)

    def _on_tree_select(self, _event):
        sel = self.tree.selection()
        if not sel or not self._on_select:
            return
        row_id = sel[0]
        diff = self._row_to_diff.get(row_id)
        if row_id in self._visible_row_ids:
            self._current_index = self._visible_row_ids.index(row_id)
            self._update_position_label()
        if diff:
            self._on_select(diff)
