"""Score summary widget (spec section 60) - a strip of score cards
showing the OVERALL fidelity and each measured per-category percentage,
built entirely from the real core.fidelity_compare.score_calculator
output for the comparison that just ran - never a hardcoded "99%
accurate" placeholder."""
import tkinter as tk
from tkinter import ttk

from gui import theme

_LABELS = {
    "content": "Content", "structure": "Structure", "unicode": "Unicode", "layout": "Layout",
    "figure": "Figures", "table": "Tables", "hyphenation": "Hyphenation", "link": "Links", "ocr": "OCR",
}

# Card label -> the exact app.comparison.difference_panel filter name that
# card must apply on click (spec: "INTERACTIVE ERROR CARDS + EXACT
# DIFFERENCE VIEW" section 1/20/32 - "EVERY ERROR SUMMARY CARD MUST BE
# CLICKABLE... Apply corresponding filter"). A card with no entry here
# (OVERALL FIDELITY, the per-category percentage cards) has no natural
# 1:1 filter and stays a plain, non-interactive count - only the cards the
# spec explicitly enumerates by name become clickable.
_CARD_TO_FILTER = {
    "PRODUCTION STATUS": None,  # a status label, not a filterable count
    "REAL PRODUCTION ERRORS": "Production Errors Only",
    "NEED REVIEW": "Need Review",
    "INFORMATIONAL / LAYOUT": "Informational / Layout",
    "CHARACTER ERRORS": "Character Errors",
    "UNICODE ERRORS": "Unicode",
    "WORD ERRORS": "Word Errors",
    "MISSING CONTENT": "Missing",
    "EXTRA CONTENT": "Added",
    "PARAGRAPH ERRORS": "Paragraph Errors",
    "FIGURE ERRORS": "Figures",
    "TABLE ERRORS": "Tables",
}


class FidelityDashboard(ttk.Frame):
    def __init__(self, parent, on_card_click=None):
        super().__init__(parent)
        palette = theme.current.palette
        self._palette = palette
        self._on_card_click = on_card_click
        self.configure(style="TFrame")
        self._cards_frame = tk.Frame(self, bg=palette["app_bg"])
        self._cards_frame.pack(fill=tk.X)
        self.show_empty()

    def _clear(self):
        for w in self._cards_frame.winfo_children():
            w.destroy()

    def show_empty(self):
        self._clear()
        tk.Label(self._cards_frame, text="Run a comparison to see fidelity scores.",
                 bg=self._palette["app_bg"], fg=self._palette["text_muted"],
                 font=theme.FONT_BODY).pack(anchor="w", padx=4, pady=6)

    _SUMMARY_LABELS = {
        "character_errors": "Character errors", "unicode_errors": "Unicode errors",
        "word_errors": "Word errors", "missing_content": "Missing content",
        "extra_content": "Extra content", "paragraph_errors": "Paragraph errors",
        "figure_errors": "Figure errors", "table_errors": "Table errors",
    }

    def show_scores(self, score_dict: dict, production_status: str = None, summary: dict = None):
        self._clear()
        palette = self._palette
        # Production status (spec section 61) - a SEPARATE signal from the
        # percentage scores below: "A document with one critical content
        # error can still be FAIL even if the overall score is 99.99%" -
        # shown first/most prominently so a high percentage can never hide
        # an unresolved content error from the reviewer at a glance.
        if production_status:
            status_color = {"PASS": palette["success"], "PASS WITH WARNINGS": palette["warning"],
                             "FAIL": palette["error"]}.get(production_status, palette["text"])
            self._card(self._cards_frame, "PRODUCTION STATUS", production_status, status_color)

        # Real-error breakdown (spec: "EXACT CONTENT DIFFERENCE ENGINE"
        # section 33 - "Do NOT make the percentage the primary
        # information... 428 REAL PRODUCTION ERRORS... 96 NEED REVIEW...
        # 8,254 INFORMATIONAL/LAYOUT FINDINGS") - shown BEFORE the
        # percentage cards, since this is what the spec explicitly wants
        # the operator to see first.
        if summary:
            self._card(self._cards_frame, "REAL PRODUCTION ERRORS", str(summary.get("real_errors", 0)),
                        palette["error"] if summary.get("real_errors") else palette["success"])
            self._card(self._cards_frame, "NEED REVIEW", str(summary.get("need_review", 0)), palette["warning"])
            self._card(self._cards_frame, "INFORMATIONAL / LAYOUT", str(summary.get("informational", 0)),
                        palette["text_muted"])
            for bucket, count in summary.get("by_type", {}).items():
                label = self._SUMMARY_LABELS.get(bucket, bucket.replace("_", " ").title())
                self._card(self._cards_frame, label.upper(), str(count), palette["text"])
            ttk.Separator(self._cards_frame, orient="vertical").pack(side=tk.LEFT, fill=tk.Y, padx=6, pady=4)

        overall = score_dict["overall_fidelity_pct"]
        self._card(self._cards_frame, "OVERALL FIDELITY", f"{overall:.2f}%",
                    palette["success"] if overall >= 95 else palette["warning"])
        for cat, data in score_dict["categories"].items():
            label = _LABELS.get(cat, cat.title())
            pct = data["verified_match_pct"]
            color = palette["success"] if pct >= 95 else (palette["warning"] if pct >= 80 else palette["error"])
            self._card(self._cards_frame, label.upper(), f"{pct:.2f}%", color,
                        sub=f"{data['confirmed_differences']} diff / {data['uncertain']} uncertain")

    def _card(self, parent, label, value, color, sub=None):
        palette = self._palette
        filter_name = _CARD_TO_FILTER.get(label)
        clickable = bool(filter_name) and self._on_card_click is not None
        card = tk.Frame(parent, bg=palette["surface"], highlightbackground=palette["border"],
                         highlightthickness=1, cursor="hand2" if clickable else "")
        card.pack(side=tk.LEFT, padx=4, pady=4, ipadx=8, ipady=4)
        value_lbl = tk.Label(card, text=value, bg=palette["surface"], fg=color,
                              font=(theme.FONT_FAMILY, 16, "bold"))
        value_lbl.pack(anchor="w")
        label_lbl = tk.Label(card, text=label, bg=palette["surface"], fg=palette["text_muted"],
                              font=theme.FONT_SMALL)
        label_lbl.pack(anchor="w")
        widgets = [card, value_lbl, label_lbl]
        if sub:
            sub_lbl = tk.Label(card, text=sub, bg=palette["surface"], fg=palette["text_faint"],
                                font=theme.FONT_SMALL)
            sub_lbl.pack(anchor="w")
            widgets.append(sub_lbl)
        if clickable:
            # Spec section 1: "EVERY ERROR SUMMARY CARD MUST BE CLICKABLE" -
            # bound on the card frame AND every label inside it, since a
            # click on any of the stacked Labels would otherwise not reach
            # the surrounding Frame's own binding in Tk.
            for w in widgets:
                w.bind("<Button-1>", lambda e, fn=filter_name: self._on_card_click(fn))
            theme.Tooltip(card, f"Click to filter: {filter_name}")
