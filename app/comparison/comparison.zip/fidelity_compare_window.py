"""Advanced Fidelity Compare window (spec: "EPUBForge - ADVANCED
FIDELITY + CONTENT + UNICODE + LAYOUT COMPARISON") - the real
implementation of the Launcher's COMPARISON card (previously a
placeholder - see app/comparison/comparison_window.py's own docstring on
why upgrading it rather than adding a redundant fourth launcher card was
the right call: its own description already promised exactly this
feature).

A completely independent, READ-ONLY subsystem (core/fidelity_compare/) -
this window only ever calls engine.run_full_comparison(), which only
ever reads the three input files. It never zones, never re-runs OCR,
never touches Reading Order/Split/Merge/XHTML/XML generation/Package
Builder/Validation in any way (spec's own repeated "DO NOT MODIFY" list).

Mirrors app/validation/validation_window.py's own "<- Home" Toplevel
pattern (same as the other two Launcher modules)."""
import os
import tkinter as tk
from tkinter import filedialog, messagebox
from tkinter import ttk

from app.comparison.difference_panel import DifferencePanel
from app.comparison.fidelity_dashboard import FidelityDashboard
from app.comparison.layout_difference_panel import LayoutDifferencePanel
from app.comparison.report_viewer import ReportViewer
from app.comparison.synchronized_pdf_viewer import SynchronizedPdfViewer
from core.fidelity_compare import engine
from core.fidelity_compare.worker import ComparisonWorker
from gui import theme

POLL_INTERVAL_MS = 150


class FidelityCompareWindow:
    def __init__(self, launcher_root: tk.Tk, on_home):
        self.launcher_root = launcher_root
        self.on_home = on_home
        palette = theme.current.palette
        self.win = tk.Toplevel(launcher_root)
        self.win.title("EPUBForge - Advanced Fidelity Compare")
        self.win.geometry("1300x860")
        self.win.configure(bg=palette["app_bg"])
        self.win.protocol("WM_DELETE_WINDOW", self._go_home)

        self._worker = None
        self._result = None
        self._original_path = tk.StringVar()
        self._epub_path = tk.StringVar()
        self._converted_path = tk.StringVar()
        # Comparison mode (spec: "ZONETOOL - ADVANCED PDF COMPARISON &
        # PRODUCTION QA ENGINE" - "[OPEN ORIGINAL PDF] [OPEN GENERATED PDF]"
        # - a direct PDF<->PDF mode with NO EPUB required, additive to the
        # existing 3-input Full Fidelity mode, never a second window/engine.
        self._mode_var = tk.StringVar(value="full")

        self._build_header(palette)
        self._build_inputs(palette)
        self._build_body(palette)
        self._apply_mode()

    # ---------------- layout ----------------

    def _build_header(self, palette):
        header = tk.Frame(self.win, bg=palette["header_bg"], height=40)
        header.pack(side=tk.TOP, fill=tk.X)
        header.pack_propagate(False)
        left = tk.Frame(header, bg=palette["header_bg"])
        left.pack(side=tk.LEFT, padx=14)
        home_btn = tk.Label(left, text="< Home", bg=palette["header_bg"], fg=palette["header_fg_muted"],
                             font=theme.FONT_BODY_BOLD, cursor="hand2", padx=6)
        home_btn.pack(side=tk.LEFT, padx=(0, 10))
        home_btn.bind("<Button-1>", lambda e: self._go_home())
        tk.Label(left, text="◈ EPUBForge - Advanced Fidelity Compare", bg=palette["header_bg"],
                 fg=palette["header_fg"], font=theme.FONT_APP_TITLE).pack(side=tk.LEFT)

    def _build_inputs(self, palette):
        frame = tk.Frame(self.win, bg=palette["panel_bg"])
        frame.pack(fill=tk.X, padx=10, pady=8)

        mode_row = tk.Frame(frame, bg=palette["panel_bg"])
        mode_row.pack(fill=tk.X, pady=(0, 4))
        tk.Label(mode_row, text="Comparison Mode:", bg=palette["panel_bg"], fg=palette["text"],
                 font=theme.FONT_BODY_BOLD).pack(side=tk.LEFT, padx=(0, 10))
        tk.Radiobutton(mode_row, text="PDF <-> PDF (Direct)", variable=self._mode_var, value="direct",
                        bg=palette["panel_bg"], fg=palette["text"], selectcolor=palette["surface"],
                        command=self._apply_mode).pack(side=tk.LEFT, padx=(0, 12))
        tk.Radiobutton(mode_row, text="PDF <-> EPUB <-> PDF (Full Fidelity)", variable=self._mode_var,
                        value="full", bg=palette["panel_bg"], fg=palette["text"], selectcolor=palette["surface"],
                        command=self._apply_mode).pack(side=tk.LEFT)

        self._original_row = self._path_row(frame, "Original PDF:", self._original_path, [("PDF files", "*.pdf")])
        self._epub_row = self._path_row(frame, "Generated EPUB:", self._epub_path, [("EPUB files", "*.epub")])
        self._converted_row = self._path_row(
            frame, "Generated PDF:", self._converted_path, [("PDF files", "*.pdf")])

        action_row = tk.Frame(frame, bg=palette["panel_bg"])
        action_row.pack(fill=tk.X, pady=(6, 0))
        self.start_btn = tk.Button(action_row, text="Start Comparison", command=self._start,
                                    bg=palette["accent"], fg=palette["accent_fg"], relief=tk.FLAT,
                                    font=theme.FONT_BODY_BOLD, padx=14, pady=6)
        self.start_btn.pack(side=tk.LEFT)
        self.cancel_btn = tk.Button(action_row, text="Cancel Comparison", command=self._cancel,
                                     state=tk.DISABLED, padx=14, pady=6)
        self.cancel_btn.pack(side=tk.LEFT, padx=(8, 0))
        self.progress_label = tk.Label(action_row, text="", bg=palette["panel_bg"], fg=palette["text_muted"],
                                        font=theme.FONT_BODY)
        self.progress_label.pack(side=tk.LEFT, padx=12)

    def _path_row(self, parent, label, var, filetypes):
        row = tk.Frame(parent, bg=parent["bg"])
        row.pack(fill=tk.X, pady=2)
        tk.Label(row, text=label, width=16, anchor="w", bg=parent["bg"]).pack(side=tk.LEFT)
        entry = tk.Entry(row, textvariable=var)
        entry.pack(side=tk.LEFT, fill=tk.X, expand=True, padx=6)
        tk.Button(row, text="Browse...", command=lambda: self._browse(var, filetypes)).pack(side=tk.LEFT)
        return row

    def _apply_mode(self):
        """Shows/hides the Generated EPUB row (spec section 2: "Do not
        start comparison until both files are loaded" - Direct mode only
        ever needs the two PDFs). Never destroys the row/its StringVar -
        just toggles visibility, so switching modes back and forth keeps
        whatever the user already typed."""
        if self._mode_var.get() == "direct":
            self._epub_row.pack_forget()
        else:
            self._epub_row.pack(fill=tk.X, pady=2, after=self._original_row)

    def _browse(self, var, filetypes):
        path = filedialog.askopenfilename(filetypes=filetypes)
        if path:
            var.set(path)

    def _build_body(self, palette):
        self.dashboard = FidelityDashboard(self.win, on_card_click=self._on_summary_card_click)
        self.dashboard.pack(fill=tk.X, padx=10, pady=(0, 6))

        # View-mode toolbar (spec: "ADVANCED PDF COMPARISON / PRODUCTION
        # PROOFING" section 2 - "Do NOT permanently consume half the
        # window with an error list. The error panel must be collapsible.
        # Provide: [Show Errors] [Hide Errors]"). Toggling only shows/hides
        # self._left_frame in the PanedWindow below - the difference
        # panel/layout panel/detail text widgets themselves are never
        # destroyed, so all their state (filter, selection, scroll
        # position) survives being hidden and shown again.
        view_bar = tk.Frame(self.win, bg=palette["app_bg"])
        view_bar.pack(fill=tk.X, padx=10, pady=(0, 4))
        self._errors_visible = True
        self.toggle_errors_btn = tk.Button(view_bar, text="Hide Errors", command=self._toggle_error_panel)
        self.toggle_errors_btn.pack(side=tk.LEFT)
        tk.Label(view_bar, text="Search:", bg=palette["app_bg"], fg=palette["text"]).pack(side=tk.LEFT, padx=(16, 4))
        self._search_var = tk.StringVar()
        search_entry = tk.Entry(view_bar, textvariable=self._search_var, width=30)
        search_entry.pack(side=tk.LEFT)
        search_entry.bind("<Return>", lambda e: self._run_search())
        tk.Button(view_bar, text="Search Differences", command=self._run_search).pack(side=tk.LEFT, padx=(6, 0))
        self.search_status_lbl = tk.Label(view_bar, text="", bg=palette["app_bg"], fg=palette["text_muted"])
        self.search_status_lbl.pack(side=tk.LEFT, padx=(10, 0))

        self._paned = ttk.Panedwindow(self.win, orient=tk.HORIZONTAL)
        self._paned.pack(fill=tk.BOTH, expand=True, padx=10, pady=(0, 8))

        self._left_frame = ttk.Frame(self._paned)
        self._paned.add(self._left_frame, weight=1)
        notebook = ttk.Notebook(self._left_frame)
        notebook.pack(fill=tk.BOTH, expand=True)

        diff_tab = ttk.Frame(notebook)
        self.difference_panel = DifferencePanel(diff_tab, on_select=self._on_difference_selected)
        self.difference_panel.pack(fill=tk.BOTH, expand=True)
        notebook.add(diff_tab, text="All Differences")

        layout_tab = ttk.Frame(notebook)
        self.layout_panel = LayoutDifferencePanel(layout_tab, on_select=self._on_difference_selected)
        self.layout_panel.pack(fill=tk.BOTH, expand=True)
        notebook.add(layout_tab, text="Layout Differences")

        self.detail_text = tk.Text(self._left_frame, height=10, wrap=tk.WORD, bg=palette["surface"],
                                    fg=palette["text"], relief=tk.FLAT, font=theme.FONT_BODY)
        self.detail_text.pack(fill=tk.X, pady=(6, 0))
        self.detail_text.insert("1.0", "Select a difference to see full detail here.")
        self.detail_text.configure(state=tk.DISABLED)

        right_frame = ttk.Frame(self._paned)
        # weight=2 (vs the error panel's weight=1 above) approximates the
        # spec's own "each viewer ~50% of the width" once BOTH sides are
        # shown - Hide Errors then gives the viewer effectively the whole
        # paned area, satisfying "PDF View Only" without a separate,
        # redundant third layout mode.
        self._paned.add(right_frame, weight=2)
        self.viewer = SynchronizedPdfViewer(right_frame)
        self.viewer.pack(fill=tk.BOTH, expand=True)

        self.report_viewer = ReportViewer(self.win)
        self.report_viewer.pack(fill=tk.X, padx=10, pady=(0, 8))

    def _toggle_error_panel(self):
        if self._errors_visible:
            self._paned.forget(self._left_frame)
            self.toggle_errors_btn.configure(text="Show Errors")
        else:
            self._paned.insert(0, self._left_frame, weight=1)
            self.toggle_errors_btn.configure(text="Hide Errors")
        self._errors_visible = not self._errors_visible

    def _run_search(self):
        """Spec section 69: "Search Text / Search Difference / Search
        Error Type / Search Page / Search Unicode" - one text box matches
        against everything a difference already exposes (original/
        converted text, type, category, page numbers, Unicode names/code
        points) rather than four separate search boxes, since a single
        query like "U+03B1" or "84" or "missing" is already unambiguous
        against these fields. Delegates to difference_panel.search(),
        which combines the query with the ACTIVE category filter without
        ever mutating the panel's own full difference list - a card click
        or filter change right after a search still sees everything. If
        the error panel is currently hidden, showing it is implied by the
        user asking to search it."""
        query = self._search_var.get().strip()
        if not query or self._result is None:
            return
        if not self._errors_visible:
            self._toggle_error_panel()
        n = self.difference_panel.search(query)
        self.search_status_lbl.configure(
            text=f"{n} match(es) for '{query}'" if n else f"No matches for '{query}'")

    # ---------------- comparison lifecycle ----------------

    def _start(self):
        direct = self._mode_var.get() == "direct"
        original_path = self._original_path.get().strip()
        epub_path = self._epub_path.get().strip()
        converted_path = self._converted_path.get().strip()
        required = [("Original PDF", original_path), ("Generated PDF", converted_path)]
        if not direct:
            required.insert(1, ("Generated EPUB", epub_path))
        for label, path in required:
            if not path or not os.path.isfile(path):
                messagebox.showwarning("Advanced Fidelity Compare", f"Please choose a valid {label} file first.")
                return

        self.start_btn.configure(state=tk.DISABLED)
        self.cancel_btn.configure(state=tk.NORMAL)
        self.progress_label.configure(text="Starting...")
        self.dashboard.show_empty()

        # Spec: "ZONETOOL - ADVANCED PDF VIEWER PERFORMANCE" section 32 -
        # "The user can start browsing before comparison finishes... This
        # is mandatory" - both PDFs are handed to the viewer IMMEDIATELY,
        # with an empty page_groups (naive page-1-to-page-1 default,
        # upgraded in-place by _on_done() below once the real content-
        # based mapping exists) - never waiting for the background
        # comparison worker just to let the user start looking at pages.
        self.viewer.load_documents(original_path, converted_path)

        if direct:
            def _run(progress_cb, should_cancel):
                return engine.run_pdf_to_pdf_comparison(original_path, converted_path,
                                                          progress_cb=progress_cb, should_cancel=should_cancel)
        else:
            def _run(progress_cb, should_cancel):
                return engine.run_full_comparison(original_path, epub_path, converted_path,
                                                   progress_cb=progress_cb, should_cancel=should_cancel)

        self._worker = ComparisonWorker(_run)
        self._worker.start()
        self.win.after(POLL_INTERVAL_MS, self._poll)

    def _cancel(self):
        if self._worker:
            self._worker.cancel()
            self.progress_label.configure(text="Cancelling...")

    def _poll(self):
        if not self._worker:
            return
        for msg in self._worker.poll():
            kind = msg[0]
            if kind == "progress":
                _, stage, current, total = msg
                self.progress_label.configure(text=f"{stage}" + (f" ({current}/{total})" if total > 1 else ""))
            elif kind == "done":
                self._on_done(msg[1])
                return
            elif kind == "error":
                self._on_error(msg[1])
                return
        self.win.after(POLL_INTERVAL_MS, self._poll)

    def _on_done(self, result: dict):
        self.start_btn.configure(state=tk.NORMAL)
        self.cancel_btn.configure(state=tk.DISABLED)
        if result.get("cancelled"):
            self.progress_label.configure(text="Cancelled - no files were modified.")
            return
        self._result = result
        self.progress_label.configure(text=f"Done - {len(result['differences'])} difference(s) found.")
        self.dashboard.show_scores(result["scores"].to_dict(), result.get("production_status"),
                                    result.get("summary"))
        self.difference_panel.set_differences(result["differences"])
        self.layout_panel.set_differences(result["differences"])
        # Upgrades the page mapping the viewer has been using since _start()
        # to the real, content-based correspondence - deliberately NOT
        # load_documents() again, which would reopen both PDFs, clear the
        # render cache, and reset the user back to page 1 of whatever they
        # were already browsing (spec section 32).
        self.viewer.update_page_groups(result["page_groups"])
        self.report_viewer.set_result(result, self._original_path.get(), self._converted_path.get())

    def _on_error(self, exc: Exception):
        self.start_btn.configure(state=tk.NORMAL)
        self.cancel_btn.configure(state=tk.DISABLED)
        self.progress_label.configure(text="Error - see message box.")
        messagebox.showerror("Advanced Fidelity Compare", f"Comparison failed:\n{exc}")

    def _on_difference_selected(self, diff):
        self.viewer.show_difference(diff)
        self.detail_text.configure(state=tk.NORMAL)
        self.detail_text.delete("1.0", tk.END)
        lines = [
            f"TYPE: {diff.type}", f"CATEGORY: {diff.category}", f"SEVERITY: {diff.severity}",
            f"CONFIDENCE: {diff.confidence} ({diff.confidence_score:.1%})",
            f"RESULT KIND: {diff.result_kind}   STAGE: {diff.comparison_stage}",
            f"ORIGINAL PAGE: {diff.original_page}    CONVERTED PAGE: {diff.converted_page}",
            f"ORIGINAL TEXT: {diff.original_text}", f"CONVERTED TEXT: {diff.converted_text}",
        ]
        # Exact hierarchical location (spec: "EXACT CONTENT DIFFERENCE
        # ENGINE" section 20 / "INTERACTIVE ERROR CARDS" section 2 -
        # "Store: ...paragraph...word...character index...") - shown only
        # when actually populated (a layout/figure/table finding has no
        # paragraph/word/character position at all, and never fakes one).
        if diff.original_paragraph or diff.converted_paragraph:
            lines.append(f"PARAGRAPH: original {diff.original_paragraph}    "
                         f"converted {diff.converted_paragraph}")
        if diff.original_word_index is not None or diff.converted_word_index is not None:
            lines.append(f"WORD: original #{diff.original_word_index}    "
                         f"converted #{diff.converted_word_index}")
        if diff.original_character_index is not None:
            lines.append(f"CHARACTER POSITION IN WORD: {diff.original_character_index}")
        if diff.original_unicode:
            u = diff.original_unicode
            lines.append(f"ORIGINAL UNICODE: {u.get('char')!r}  {u.get('codepoint')}  "
                         f"{u.get('name')}  ({u.get('script')})")
        if diff.converted_unicode:
            u = diff.converted_unicode
            lines.append(f"CONVERTED UNICODE: {u.get('char')!r}  {u.get('codepoint')}  "
                         f"{u.get('name')}  ({u.get('script')})")
        if diff.original_layout:
            lines.append(f"ORIGINAL LAYOUT: {diff.original_layout}")
        if diff.converted_layout:
            lines.append(f"CONVERTED LAYOUT: {diff.converted_layout}")
        if diff.explanation:
            lines.append(f"EXPLANATION: {diff.explanation}")
        self.detail_text.insert("1.0", "\n".join(lines))
        self.detail_text.configure(state=tk.DISABLED)

    def _on_summary_card_click(self, filter_name: str):
        """Spec: "INTERACTIVE ERROR CARDS + EXACT DIFFERENCE VIEW" section
        1/32 - clicking a summary card applies the matching filter and
        jumps straight to the first difference in it; difference_panel's
        own <<TreeviewSelect>> firing from that selection already calls
        _on_difference_selected above (the SAME callback a manual row
        click uses), which navigates both viewers/highlights/shows
        details - no separate navigation path to keep in sync."""
        if self._result is None:
            return
        found = self.difference_panel.apply_filter_and_select_first(filter_name)
        if not found:
            messagebox.showinfo("Advanced Fidelity Compare", f"No differences found for: {filter_name}")

    def _go_home(self):
        self.win.destroy()
        self.on_home()


def open_window(launcher_root: tk.Tk, on_home):
    return FidelityCompareWindow(launcher_root, on_home)
